Repair and Sales Inventory System

**LOGIN DETAILS** 

admin
user: admin
pass: admin

user
user: test
pass: test

